#!/bin/bash
arm-none-eabi-gcc -march=armv5t -mbig-endian -nostdlib  -fpic   -o boot.elf boot.c stubs.S
arm-none-eabi-objcopy -O binary boot.elf boot.bin
