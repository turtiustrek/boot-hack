Execution steps:

1-install gcc-arm-none-eabi
($sudo apt install gcc-arm-none-eabi)

2- execute the following command. 
($sh ./build.sh)

3- make sure to install python3 and pyserial and execute the script.
($python3 FILLMEM.py)
