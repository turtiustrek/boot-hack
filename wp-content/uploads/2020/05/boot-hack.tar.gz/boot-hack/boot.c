
void main(){
printf("Hello");
 return;
}


